const supabaseUrl = 'https://bagqujotwmmsghcemsdi.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJhZ3F1am90d21tc2doY2Vtc2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY1Mjc2MDcsImV4cCI6MjA4MjEwMzYwN30.I0c-C1wBbJ2uLYhBrlcDofhEvKqXpiMh3P7O6bpJByo';
const _supabase = supabase.createClient(supabaseUrl, supabaseKey);

const ADMIN_EMAIL = "don0543339570@gmail.com";
let currentUser = null;

async function checkStatus() {
    const { data: { user } } = await _supabase.auth.getUser();
    if (user) {
        showSecureArea(user);
    } else {
        updateStatsUI(); // Load public stats for non-logged users
    }
}

async function performLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-pass').value;
    const btn = document.getElementById('btn-login');
    const err = document.getElementById('login-error');

    btn.innerText = "AUTHENTICATING...";
    const { data, error } = await _supabase.auth.signInWithPassword({ email, password });

    if (error) {
        err.innerText = error.message.toUpperCase();
        err.classList.remove('hidden');
        btn.innerText = "UNFOLD DASHBOARD";
    } else {
        showSecureArea(data.user);
    }
}

function showSecureArea(user) {
    currentUser = user;
    const isAdmin = user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase();

    // UI Transformation
    document.getElementById('login-hub').classList.add('hidden');
    document.getElementById('secure-area').classList.remove('hidden');
    document.getElementById('auth-status-nav').innerHTML = `
        <span class="text-[9px] font-black uppercase bg-white/20 px-3 py-1 rounded-full">${isAdmin ? 'Admin' : 'Teacher'}</span>
        <button onclick="handleLogout()" class="bg-rose-500 px-4 py-1.5 rounded-xl text-[10px] font-black">LOGOUT</button>
    `;

    updateStatsUI();
    if (isAdmin) renderAdmin(); else renderTeacher();
}

function handleLogout() { _supabase.auth.signOut().then(() => location.reload()); }

checkStatus();