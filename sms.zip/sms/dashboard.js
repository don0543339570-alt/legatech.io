const _SB_URL = "https://bagqujotwmmsghcemsdi.supabase.co";
const _SB_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJhZ3F1am90d21tc2doY2Vtc2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY1Mjc2MDcsImV4cCI6MjA4MjEwMzYwN30.I0c-C1wBbJ2uLYhBrlcDofhEvKqXpiMh3P7O6bpJByo";
const _supabase = supabase.createClient(_SB_URL, _SB_KEY);

let currentUserID = null;
let currentUserRole = 'teacher';

// AUTH
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-pass').value;
    if (document.getElementById('access-code').value !== "LEGATECH2025") return alert("Invalid Institutional Code");
    
    const { data, error } = await _supabase.auth.signInWithPassword({ email, password: pass });
    if (error) return alert(error.message);
    
    currentUserID = data.user.id;
    initApp(data.user.id, email);
});

async function initApp(uid, email) {
    const { data } = await _supabase.from('profiles').select('role').eq('id', uid).single();
    currentUserRole = data?.role || 'teacher';
    document.getElementById('user-initial').innerText = email.charAt(0).toUpperCase();
    document.getElementById('role-badge').innerText = currentUserRole.toUpperCase() + " ACCESS";

    if (currentUserRole === 'admin') {
        document.getElementById('admin-only-nav').classList.remove('hidden');
        document.getElementById('admin-assign-field').classList.remove('hidden');
        loadAdminControls();
    }
    document.getElementById('view-login').classList.add('hidden');
    document.getElementById('view-app').classList.remove('hidden');
    document.getElementById('attendance-date').valueAsDate = new Date();
    showSection('dashboard');
}

// ADMIN FILTERING
async function loadAdminControls() {
    const { data: teachers } = await _supabase.from('profiles').select('id, full_name').eq('role', 'teacher');
    document.getElementById('filter-container').innerHTML = `
        <select onchange="loadStudentHub(this.value)" class="p-3 bg-white border rounded-xl font-black text-[10px] uppercase text-slate-500">
            <option value="all">Global View</option>
            <option value="${currentUserID}">My Class</option>
            ${(teachers || []).map(t => `<option value="${t.id}">${t.full_name}</option>`).join('')}
        </select>`;
    document.getElementById('std-teacher-assign').innerHTML = `
        <option value="${currentUserID}">Myself (Admin)</option>
        ${(teachers || []).map(t => `<option value="${t.id}">${t.full_name}</option>`).join('')}`;
}

// NAVIGATION
function showSection(name) {
    document.querySelectorAll('.content-sec').forEach(s => s.classList.add('hidden'));
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.getElementById('sec-' + name).classList.remove('hidden');
    document.getElementById('btn-' + name).classList.add('active');
    document.getElementById('section-title').innerText = name.toUpperCase();
    if (name === 'students') loadStudentHub();
    if (name === 'attendance') loadAttendanceList();
    if (name === 'grades') loadGrades();
    if (name === 'admin') loadStaffList();
    if (name === 'dashboard') refreshStats();
}

// DATA LOADING
async function loadStudentHub(filterId = 'all') {
    let q = _supabase.from('students').select('*');
    if (filterId !== 'all') q = q.eq('teacher_id', filterId);
    else if (currentUserRole !== 'admin') q = q.eq('teacher_id', currentUserID);
    
    const { data } = await q.order('name');
    document.getElementById('student-list').innerHTML = (data || []).map(s => `
        <div class="bg-white p-6 rounded-[2rem] border border-slate-100 flex justify-between items-center group">
            <div><h4 class="font-black text-slate-800 text-sm">${s.name}</h4><p class="text-[9px] font-bold text-slate-400 uppercase">${s.grade_level}</p></div>
            <button onclick="printReport('${s.id}', '${s.name}', '${s.grade_level}')" class="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl font-black text-[9px] uppercase group-hover:bg-indigo-600 group-hover:text-white transition">Report</button>
        </div>`).join('');
}

async function loadAttendanceList() {
    const date = document.getElementById('attendance-date').value;
    const { data: stds } = await _supabase.from('students').select('*').order('name');
    const { data: recs } = await _supabase.from('attendance').select('*').eq('date', date);
    document.getElementById('attendance-list').innerHTML = (stds || []).map(s => {
        const r = recs ? recs.find(at => at.student_id === s.id) : null;
        const status = r ? r.status : 'unmarked';
        return `<tr><td class="p-8 font-bold text-sm">${s.name}</td><td class="p-8"><span class="px-3 py-1 rounded-lg font-black text-[10px] uppercase ${status === 'present' ? 'bg-emerald-100 text-emerald-600' : status === 'absent' ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-400'}">${status}</span></td><td class="p-8 text-right space-x-4"><button onclick="markAttendance('${s.id}', 'present')" class="text-emerald-500 font-black">P</button><button onclick="markAttendance('${s.id}', 'absent')" class="text-rose-500 font-black">A</button></td></tr>`;
    }).join('');
}

async function markAttendance(sid, stat) {
    const date = document.getElementById('attendance-date').value;
    await _supabase.from('attendance').upsert({ student_id: sid, date, status: stat, teacher_id: currentUserID }, { onConflict: 'student_id, date' });
    loadAttendanceList(); refreshStats();
}

async function loadGrades() {
    const { data: stds } = await _supabase.from('students').select('id, name');
    document.getElementById('grade-student-select').innerHTML = (stds || []).map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    const { data: grd } = await _supabase.from('grades').select('*, students(name)');
    document.getElementById('grade-table-body').innerHTML = (grd || []).map(g => `<tr><td class="p-8 font-bold text-sm">${g.students?.name}</td><td class="p-8 text-[10px] font-bold uppercase text-slate-400">${g.subject}</td><td class="p-8 text-center font-black text-indigo-600">${Number(g.class_score)+Number(g.exam_score)}%</td><td class="p-8 text-right"><button onclick="deleteGrade('${g.id}')" class="text-rose-300 font-black text-[10px]">REMOVE</button></td></tr>`).join('');
}

// SMART STATS
async function refreshStats() {
    const { count } = await _supabase.from('students').select('*', { count: 'exact', head: true });
    document.getElementById('stat-students').innerText = count || 0;

    const today = new Date().toISOString().split('T')[0];
    const { data: att } = await _supabase.from('attendance').select('status').eq('date', today);
    if (att && att.length > 0) {
        const pres = att.filter(a => a.status === 'present').length;
        document.getElementById('stat-attendance').innerText = Math.round((pres/att.length)*100) + "%";
    }

    const { data: grades } = await _supabase.from('grades').select('student_id, class_score, exam_score, students(name)');
    if (grades && grades.length > 0) {
        let topName = ""; let topAvg = 0; let map = {};
        grades.forEach(g => {
            if(!map[g.student_id]) map[g.student_id] = { name: g.students.name, sum: 0, count: 0 };
            map[g.student_id].sum += (Number(g.class_score) + Number(g.exam_score));
            map[g.student_id].count++;
        });
        for(let id in map) {
            let avg = map[id].sum / map[id].count;
            if(avg > topAvg) { topAvg = avg; topName = map[id].name; }
        }
        document.getElementById('stat-top-student').innerText = topName || "N/A";
    }
}

// FORM SUBMISSIONS
document.getElementById('form-add-student').addEventListener('submit', async (e) => {
    e.preventDefault();
    const tId = currentUserRole === 'admin' ? document.getElementById('std-teacher-assign').value : currentUserID;
    await _supabase.from('students').insert([{ name: document.getElementById('std-name').value, grade_level: document.getElementById('std-grade').value, teacher_id: tId }]);
    toggleModal('modal-add-student'); loadStudentHub(); refreshStats();
});

document.getElementById('form-add-grade').addEventListener('submit', async (e) => {
    e.preventDefault();
    await _supabase.from('grades').insert([{ student_id: document.getElementById('grade-student-select').value, subject: document.getElementById('grade-subject').value, class_score: Number(document.getElementById('class-score').value), exam_score: Number(document.getElementById('exam-score').value) }]);
    toggleModal('modal-add-grade'); loadGrades(); refreshStats();
});

document.getElementById('form-add-teacher')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('t-email').value;
    const { data, error } = await _supabase.auth.signUp({ email, password: document.getElementById('t-pass').value });
    if (error) return alert(error.message);
    await _supabase.from('profiles').upsert([{ id: data.user.id, email, full_name: document.getElementById('t-name').value, role: 'teacher' }]);
    alert("Teacher Created!"); loadStaffList(); loadAdminControls();
});

async function loadStaffList() {
    const { data } = await _supabase.from('profiles').select('*').eq('role', 'teacher');
    document.getElementById('staff-list').innerHTML = (data || []).map(t => `<div class="p-6 flex justify-between items-center"><div><p class="font-black text-slate-800 text-xs">${t.full_name}</p><p class="text-[10px] text-slate-400">${t.email}</p></div><button onclick="deleteStaff('${t.id}')" class="text-rose-400 font-black text-[10px]">REMOVE</button></div>`).join('');
}

function printReport(sid, name, level) {
    _supabase.from('grades').select('*').eq('student_id', sid).then(({data}) => {
        let rows = (data || []).map(s => `<tr><td style="border:1px solid #000;padding:10px;">${s.subject.toUpperCase()}</td><td style="border:1px solid #000;padding:10px;text-align:center;">${s.class_score}</td><td style="border:1px solid #000;padding:10px;text-align:center;">${s.exam_score}</td><td style="border:1px solid #000;padding:10px;text-align:center;font-weight:900;">${Number(s.class_score)+Number(s.exam_score)}</td></tr>`).join('');
        document.getElementById('printable-area').innerHTML = `<div style="padding:40px; font-family:sans-serif;"><h1 style="text-align:center;border-bottom:2px solid #000;">ACADEMIC REPORT</h1><p><strong>NAME:</strong> ${name} | <strong>CLASS:</strong> ${level}</p><table style="width:100%;border-collapse:collapse;margin-top:20px;"><thead><tr style="background:#f0f0f0;"><th>SUBJECT</th><th>CLASS</th><th>EXAM</th><th>TOTAL</th></tr></thead><tbody>${rows}</tbody></table></div>`;
        window.print();
    });
}

function toggleModal(id) { document.getElementById(id).classList.toggle('hidden'); }
async function deleteStaff(id) { if(confirm("Remove Teacher?")) { await _supabase.from('profiles').delete().eq('id', id); loadStaffList(); loadAdminControls(); } }
async function deleteGrade(id) { if(confirm("Delete Grade?")) { await _supabase.from('grades').delete().eq('id', id); loadGrades(); } }
function handleLogout() { window.location.reload(); }